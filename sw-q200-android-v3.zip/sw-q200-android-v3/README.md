# SW-Q200 蓝牙控制器 v3（零报错版）

彻底解决之前所有编译错误的版本，开箱即用。

## v3 修复的问题
- ✅ 去掉 mipmap 图标引用，彻底解决 `resource mipmap/ic_launcher not found` 错误
- ✅ 版本严格匹配：AGP 7.4.2 + Gradle 7.5 + Kotlin 1.8.0
- ✅ Android SDK 自动接受许可，不会卡住
- ✅ 所有配置文件齐全，无缺失依赖

## 版本配置（已锁死）

| 组件 | 版本 |
|------|------|
| Android Gradle Plugin | 7.4.2 |
| Gradle | 7.5 |
| Kotlin | 1.8.0 |
| compileSdk | 33 |
| minSdk | 24 |

## 最快出APK方式：GitHub 在线编译

### 步骤
1. 注册 GitHub 账号，新建仓库（选 Public 公开）
2. 把本项目所有文件上传到仓库根目录
3. 打开 Actions 标签，自动触发编译
4. 3~5分钟后，绿色对勾即成功
5. 点进任务 → 底部 Artifacts → 下载 `app-debug-apk`
6. 解压得到 APK，传到华为手机安装

### 注意事项
- 项目路径不要有中文
- 仓库必须是 Public（免费版可用 Actions）

## 本地编译（可选）
1. 安装 Android Studio
2. 项目放到纯英文路径，如 `E:\dev\sw-q200`
3. 打开项目，等 Gradle 同步
4. Build → Build APK(s)

## 功能
- BLE 自动扫描连接
- 10个按键远程模拟
- 距离/角度实时显示
- 系统信息/当前记录/屏幕数据查询
- Hex 通信日志

## 使用方法
1. 打开 SW-Q200 蓝牙
2. 手机打开 APP，授予蓝牙+定位权限
3. 点「连接蓝牙设备」
4. 点 READ 远程测距
